const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// Add a new book
router.post('/add', async (req, res) => {
  try {
    const { title, author, genre, coverImage, isFavorite } = req.body;

    if (!title || !author) {
      return res.status(400).json({ error: 'Title and Author are required.' });
    }

    const newBook = new Book({ title, author, genre, coverImage, isFavorite });
    await newBook.save();
    res.status(201).json(newBook);
  } catch (err) {
    res.status(500).json({ error: 'Server Error' });
  }
});

// Delete a book
router.delete('/:id', async (req, res) => {
  try {
    const deletedBook = await Book.findByIdAndDelete(req.params.id);
    if (!deletedBook) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.status(200).json({ message: 'Book deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete book' });
  }
});


// Get all books
router.get('/', async (req, res) => {
  try {
    const books = await Book.find().sort({ createdAt: -1 });
    res.status(200).json(books);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch books' });
  }
});

module.exports = router;
