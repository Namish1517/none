import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Footer from '../Components/Footer';
import axios from 'axios';

export default function Home() {
  const [books, setBooks] = useState([]);
  const [favorites, setFavorites] = useState({});

  const toggleFavorite = (id) => {
    setFavorites((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/books");
        setBooks(res.data);
      } catch (err) {
        console.error("Failed to fetch books:", err);
      }
    };

    fetchBooks();
  }, []);
  
  const handleDelete = async (id) => {
  const confirmDelete = window.confirm('Are you sure you want to delete this book?');
  if (!confirmDelete) return;

  try {
    const res = await fetch(`http://localhost:5000/api/books/${id}`, {
      method: 'DELETE',
    });

    const data = await res.json();
    console.log("Delete response:", data);

    if (!res.ok) throw new Error(data.error || 'Failed to delete');

    setBooks((prevBooks) => prevBooks.filter((book) => book._id !== id));
    alert('Book deleted successfully');
  } catch (err) {
    console.error('Error deleting:', err.message);
    alert('Failed to delete book');
  }
};


  return (
    <div className="w-screen">
      <div className="flex flex-col min-h-screen text-[#00272B]">
        <nav className="w-full bg-[#457B9D] text-white shadow-md py-5 px-6 flex items-center justify-between fixed top-0 left-0 z-50">
          <div className="flex items-center space-x-8 pl-4">
            <div className="text-2xl font-bold">BookCatalog</div>
            <span className="text-[#C7F0BD] font-semibold">Home</span>
            <Link to="/update-profile" className="text-white font-semibold transition hover:text-[#C7F0BD]">
              Profile
            </Link>
            <Link to="/add-book" className="text-white font-semibold transition hover:text-[#C7F0BD]">
              Add Books
            </Link>
            <Link to="/cart" className="hidden sm:inline text-white font-semibold transition hover:text-[#C7F0BD]">
              🛒 Cart
            </Link>
          </div>
          <div className="md:flex space-x-4"></div>

        </nav>

        <main className="pt-32 px-6 text-center">
          <h1 className="text-3xl font-bold text-[#457B9D] mb-4">Welcome Back!</h1>
          <p className="text-gray-700">
            This is your personalized home dashboard. Use the navigation to update your profile, add books, or check your cart.
          </p>
        </main>

        <section className="px-6 py-12">
          <h2 className="text-2xl font-semibold text-[#457B9D] mb-6 text-center">Book Library</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {books.map((book) => (
              <div key={book._id} className="bg-white rounded-2xl shadow p-4 border hover:shadow-lg transition relative">
                <img
                  src={book.cover}
                  alt={book.title}
                  className="w-full h-48 object-cover rounded-xl mb-4"
                />
                <h3 className="text-lg font-semibold">{book.title}</h3>
                <p className="text-sm text-gray-600">by {book.author}</p>
                <p className="text-xs text-gray-500 italic mt-1">Genre: {book.genre}</p>
                <button
                  onClick={() => toggleFavorite(book._id)}
                  className="absolute top-4 right-4 text-xl"
                
                >
                  {favorites[book._id] ? '⭐' : '☆'}
                </button>
                <button
                  onClick={() => handleDelete(book._id)}
                  className="absolute bottom-4 right-4 text-sm text-red-600 hover:text-red-800"
                
                >
                 delete
                </button>

              </div>
            ))}
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
}

